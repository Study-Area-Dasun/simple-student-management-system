package lk.ijse.dep10.simplestudentmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleStudentManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
