package lk.ijse.dep10.simplestudentmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleStudentManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleStudentManagementSystemApplication.class, args);
	}

}
